package com.example.videodownloadingline

import android.app.Application


class Application : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}